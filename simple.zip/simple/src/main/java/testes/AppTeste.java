package testes;

import org.junit.jupiter.api.Test;

import projetoES.simple.App;
import projetoES.simple.Metric;

class AppTeste {
	
	private App app = new App();

	@Test
	public void escreveVFTest() {
		Metric m = new Metric ("LOC",">",80);
		int row = 4;
		app.escreveVF(m, row);
//		this.app.escreveVF(m, row);
		
	}
	
	@Test
	public void searchTest() {
		Metric m = new Metric ("LOC",">",80);
		int row = 4;
		this.app.search(m, row);
		
	}
	
	@Test
	public void changeTest() {
		Metric m = new Metric ("LOC",">",80);
		int row = 4;
		String bool = "TRUE";
		this.app.change(m, row, bool);
	}
	
}
