package testes;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.jupiter.api.Test;

import projetoES.simple.App;

class ReadFileTest {

	@Test
	void test() throws InvalidFormatException, IOException {
		App app = new App();
//		App app = new App("C:\\Users\\diana\\Desktop\\Defeitos.xlsx");
		app.readFile("C:\\Users\\diana\\Desktop\\Defeitos.xlsx");
		String [][] xx = app.getRowData();
		String [] header = app.getColumnNames();
		assertEquals("FALSE" , xx[12][8]);
		assertEquals("iPlasma", header[9]);
		
	}

}
